package com.thermofisher.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTabletest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1. load and register the driver
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded..");
			
		//2. Obtain the Database connection
			String username = "root";
			String password = "password";
			
			String url = "jdbc:mysql://localhost:3306/thermofisherdb";
			
			Connection con = 
					DriverManager.getConnection(url, username, password);
			System.out.println(con);
			
			//3. fire the database queres
			Statement st = con.createStatement();
			
			String createQRy="create table employee "
					+ "(id int primary key , "
					+ "name varchar(100), "
					+ "emailid varchar(100), salary double, "
					+ "mobile int)";
			
			st.execute(createQRy);
			
			System.out.println("table is created...");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
