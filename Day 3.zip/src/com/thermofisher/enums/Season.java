package com.thermofisher.enums;

//pool of constants...

public enum Season {
	//static final variables..
	WINTER (3),
	SUMMER (5),
	SPRING (7)	
	;
	
	int value;
	
	Season(int value){
		this.value = value;
	}
}
