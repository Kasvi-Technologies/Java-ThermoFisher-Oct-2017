package com.thermofisher.enums;

public class Seasontest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Season s = Season.SPRING;
		
		Season s1 = Season.WINTER;
		
		System.out.println(s);
		System.out.println(s1);
		
		if (s1 == Season.WINTER) {
			//BL
			System.out.println("BL executed..");
		}  
		
		if (s == Season.SUMMER){
			System.out.println("BL not executed..");
		}
		
		Season s2[] = Season.values();
		for(Season s5: s2){
			System.out.println(s5.value);
		}
		
		Season s10 = Season.WINTER;
		System.out.println(s10.value);
		
	}

}
