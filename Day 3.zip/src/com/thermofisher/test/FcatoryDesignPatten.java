package com.thermofisher.test;

public class FcatoryDesignPatten {

	public static void main(String[] arg){
		
		Vehicle v = getVehicle("car");
		v.drive();
		
		Vehicle v1 = getVehicle("bike");
		v1.drive();
		
	}
	
	public static Vehicle getVehicle(String type){
		
		if("car".equals(type)){
			return new Car();
		} else if ("bike".equals(type)) {
			return new Bike();
		}		
		return null;
	}
}

//return one of the class from its family hierarchy

