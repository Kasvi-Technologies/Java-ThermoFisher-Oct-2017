package com.thermofisher.test;

public class Bike extends Vehicle{

	public void drive(){
		System.out.println("bike drive..");
	}

	
}
