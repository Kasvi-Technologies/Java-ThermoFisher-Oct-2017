package com.thermofisher.test;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class jdk18featurestest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Lambda expressions
		//Combination of anonymous classes 
		//with functional interface
		
		//Functional Interface-> 
		//an interface which contain only 
		//one abstract method
		
		//Ex:Runnable, Comparator
		
		
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("Exampleof anonymous");
			}
		};
		
		Thread t = new Thread(runnable);
		t.start();
		
		//Lambda expression - will reduce the java code. 
		//except that no benifits using lambda expression
		
		Runnable runnable1 = () -> {
			System.out.println("Exampleof Lambdsa expre");
		};
		
		Thread t1 = new Thread(runnable1);
		t1.start();
		
		Sample s = (salary , hike) -> {
			return salary + (salary * hike/100);
		};
		
		double hikedSal = s.hikeSalary(3222323, 10);
		System.out.println(hikedSal);
		
		//JDK 1.8 version of for loops
		//completly seperate the business logic
		
		List<Integer> intList = new ArrayList<Integer>();
		
		intList.add(10);
		intList.add(20);
		intList.add(30);
		intList.add(40);
		intList.add(50);
		System.out.println("jdk 1.8 FOR LOOPS");
		intList.forEach(
				new Consumer<Integer>() {
					@Override
					public void accept(Integer arg0) {
						// TODO Auto-generated method stub
						//BL............
						System.out.println(arg0);
					}					
				}				
		);	
	}
} //class closing

@FunctionalInterface
interface Sample {	
	public double hikeSalary(double salary, int hike);
}









