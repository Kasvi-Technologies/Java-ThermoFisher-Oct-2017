package com.thermofisher.test;

public class Car extends Vehicle {

	public void drive(){
		System.out.println("car drive..");
	}

}
