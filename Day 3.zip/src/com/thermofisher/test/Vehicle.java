package com.thermofisher.test;

public class Vehicle {

	public void drive(){
		System.out.println("vehicle drive..");
	}
}
