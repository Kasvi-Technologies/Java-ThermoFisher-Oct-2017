package com.thermofisher.test;

public class SingletonDPTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingletonEx ex = 
				SingletonEx.getSingletonEx();
		
		SingletonEx ex1 = 
				SingletonEx.getSingletonEx();
		
		SingletonEx ex2 = 
				SingletonEx.getSingletonEx();
		
		System.out.println(ex);
		System.out.println(ex1);
		System.out.println(ex2);
	}

}

//Singleton
//allows us to create only one instance perJVM

class SingletonEx {
	private static SingletonEx singletonEx = null;
	private SingletonEx(){
		
	}
	public synchronized static SingletonEx getSingletonEx(){
		if (singletonEx == null) {
			singletonEx = new SingletonEx();
		}
		
		return singletonEx;
	}
	
	
}






