package com.thermofisher.junitex;

import org.junit.Test;

import junit.framework.Assert;

public class TestJunit {

	@Test
	public void testSum(){
		Assert.assertEquals(sum(5,-6), 11);
	}
	
	@Test
	public void testEmployee(){
		Assert.assertEquals(addEmployee(), 1);
	}
	
	public int sum(int a, int b) {
		return a+b;
	}
	
	public int addEmployee(){
		//DL...
		//if any error return 0
		
		return 1;
	}
}
