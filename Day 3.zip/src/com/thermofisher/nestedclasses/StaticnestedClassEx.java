package com.thermofisher.nestedclasses;

import com.thermofisher.threads.BankAccount;

public class StaticnestedClassEx {

	static int data = 100;
	static BankAccount ba;
	static class nestedClass {
		public void display(){
			System.out.println("data:" + data);
			System.out.println("ba:" + ba);			
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticnestedClassEx.nestedClass nestedClass = 
				new StaticnestedClassEx.nestedClass();
		
		nestedClass.display();
	}

}
