package com.thermofisher.nestedclasses;

import com.thermofisher.threads.BankAccount;

public class MemberInnerClass {	
	int data = 100;	
	BankAccount ba;
	
	class MIC {
		//inner class can access all data and members of
		//outer class.
		public void displayData(){
			System.out.println("Data:" + data);
		}
	}	
	//MemberInnerClass$MIC
	//new MemberInnerClass$MIC();
	public static void main(String[] args){
		MemberInnerClass outer = new MemberInnerClass();
		
		MemberInnerClass.MIC mic = outer.new MIC();
		mic.displayData();
	}
}
