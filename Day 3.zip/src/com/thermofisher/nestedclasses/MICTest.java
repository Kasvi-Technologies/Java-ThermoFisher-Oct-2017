package com.thermofisher.nestedclasses;

import com.thermofisher.nestedclasses.MemberInnerClass.MIC;

public class MICTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MemberInnerClass outer = new MemberInnerClass();
		
		MIC mic = outer.new MIC();
		
		mic.displayData();
	}

}
