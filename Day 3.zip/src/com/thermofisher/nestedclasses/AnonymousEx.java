package com.thermofisher.nestedclasses;

public class AnonymousEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Example of Anonymous Inner classes
		//Parent class -> Abstract or interface
		
		//no need to create an child classes for 
		//providing the implementations
		
		//implementation can be provided on the fly
		
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("Exampleof anonymous");
			}
		};
		
		Thread t = new Thread(runnable);
		t.start();
		
		
		
	}

}
