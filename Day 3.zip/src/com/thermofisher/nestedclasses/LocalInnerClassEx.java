package com.thermofisher.nestedclasses;

public class LocalInnerClassEx {
	int data =100;
	//local inner class 
	// class template is create inside a method
	public void display (){
		class localinner {
			public void displayData(){
				System.out.println("data of outer:" + data);
			}
		}
		
		localinner li = new localinner();
		li.displayData();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalInnerClassEx outer = new LocalInnerClassEx();
		outer.display();
	}

}
