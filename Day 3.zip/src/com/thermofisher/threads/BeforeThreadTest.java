package com.thermofisher.threads;

public class BeforeThreadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("main method starting");
		
		//BL
		//BL
		
		for (int i= 0; i< 10; i++) {
			//BL might take 10 to 15 mins
			System.out.println("First for loop:" + i);
		}
		
		System.out.println("Second business logic started..");
		for (int j= 0; j< 10; j++) {
			//BL might take 10 to 15 mins
			System.out.println("Second for loop:" + j);
		}

		
		//BL
		System.out.println("main method ended..");
		
	}

}
