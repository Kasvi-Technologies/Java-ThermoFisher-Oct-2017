package com.thermofisher.threads;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ExecutorService service = 
				Executors.newFixedThreadPool(3);		
		
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("Exampleof anonymous");
			}
		};
		
		service.execute(runnable);
		
		Future f = service.submit(runnable);
		
		Callable<String> callable = new Callable<String>() {
			@Override
			public String call() {
				// TODO Auto-generated method stub
				System.out.println("Exampleof anonymous");
				return "success";
			}
		};
		Future<String> f1 = service.submit(callable);
		try {
			System.out.println(f.get()); //null
			
			System.out.println(f1.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //null
		
		service.shutdown();
	}

}
