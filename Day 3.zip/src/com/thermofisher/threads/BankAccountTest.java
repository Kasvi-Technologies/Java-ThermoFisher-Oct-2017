package com.thermofisher.threads;

public class BankAccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BankAccount ba = new BankAccount();
		ba.setId(100);
	//	ba.setAmount(1000);
		
		WithDrawThread wThread =  
				new WithDrawThread(ba);
		DepositThread dThread =  
				new DepositThread(ba);
		
		wThread.start();
		//bl
		//bl 
		//15
		dThread.start();
		
	}

}
