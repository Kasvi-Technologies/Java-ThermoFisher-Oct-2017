package com.thermofisher.threads;

public class BankAccount {

	private int id;
	private double amount;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public synchronized void deposit(int amount){
		System.out.println("Deposit started.. ");
		this.amount = this.amount + amount;
		if(this.amount>=1000){
			System.out.println("calling notify...");
			notify();
		}
		
		System.out.println("Deposit completed with "
				+ "final amount:.. "+ this.amount);
	}
	
	
	public synchronized void withdraw(int amount){
		System.out.println("withdraw started.. ");
		//if amount is lessthan 1000, WT is in 
		// waiting state until some other threads deposit
		//the amount
		if(this.getAmount() < 1000){
			try {
				System.out.println("Waiting state..");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		this.amount = this.amount - amount;
		System.out.println("withdraw completed "
				+ "with final amount:.. "+ this.amount);
	}
	
}
