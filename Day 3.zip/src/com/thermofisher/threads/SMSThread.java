package com.thermofisher.threads;

public class SMSThread extends Thread {
	
	public void run() {
		System.out.println("Starting SMS Thread..");
		
		//BL to send the sms's
		for (int i = 0 ; i< 50;i++){
			System.out.println(Thread.currentThread().getName() + i);
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Ending SMS Thread..");
	}

}
