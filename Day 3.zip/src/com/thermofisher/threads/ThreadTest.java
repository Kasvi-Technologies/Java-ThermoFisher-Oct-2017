package com.thermofisher.threads;

public class ThreadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Main Method started..");
		
		String mainThreadName = 
				Thread.currentThread().getName();
		System.out.println(mainThreadName);
		
		SMSThread smsThread = new SMSThread();
		smsThread.setName("SMS Thread");
				
		MailThread mailThread = new MailThread();
		Thread t = new Thread(mailThread);
		t.setName("Mail Thread");
		
		smsThread.start();
		t.start();
		
		try {
			smsThread.join();
			t.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		//BL.., which you need to be executed 
		//after completion of threads
		
		
		System.out.println("Main Method completed..");

	}

}
