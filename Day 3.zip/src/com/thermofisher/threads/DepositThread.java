package com.thermofisher.threads;

public class DepositThread extends Thread{
	
	private BankAccount bankAccount;

	public DepositThread(BankAccount bankAccount) {
		//super();
		this.bankAccount = bankAccount;
	}

	public void run(){
		System.out.println("Started Deposit Thread.");
		
		bankAccount.deposit(1000);
		
		System.out.println("Ended Deposit Thread.");
	}
}
