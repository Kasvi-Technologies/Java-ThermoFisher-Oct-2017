package com.thermofisher.threads;

public class WithDrawThread extends Thread{
	private BankAccount bankAccount;

	public WithDrawThread(BankAccount bankAccount) {
		//super();
		this.bankAccount = bankAccount;
	}

	public void run(){
		System.out.println("Started Withdraw Thread.");
		
		bankAccount.withdraw(500);
		
		System.out.println("Ended withdraw Thread.");
	}
}
