import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class CalculatorImpl extends UnicastRemoteObject
					implements Calculator {

	public CalculatorImpl()
							throws RemoteException{
		
	}
	@Override
	public int sum(int a, int b) 
							throws RemoteException {
		// TODO Auto-generated method stub
		return a+b;
	}

}
