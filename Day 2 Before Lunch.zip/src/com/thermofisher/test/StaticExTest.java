package com.thermofisher.test;

import com.thermofisher.beans.StaticEx;

//java StaticExTest
//StaticExTest.main(null);

public class StaticExTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticEx.b = 100;
		System.out.println(StaticEx.b);
		
		StaticEx ex1 = new StaticEx();
		StaticEx ex2 = new StaticEx();
		
		System.out.println(ex1.b);		
		ex2.b = 500;
		System.out.println(ex1.b);
		
		
	}

}
