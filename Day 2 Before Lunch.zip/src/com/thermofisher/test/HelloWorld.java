package com.thermofisher.test;
import com.thermofisher.beans.Employee;

public class HelloWorld {

	//void as a return type
	// void means, your method is not returning any value	
	
	//is the default method, which 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Basic Application...");
		
		//Data Types
		// To hold some information in your application
		
		//byte, short , int, long -> numeric values
		
		//byte -> 8 bits
		//short-> 16
		//int 32
		//long 64
		
		//float, double -> decimal values
		//float 32 bits with 7 decimal digits
		//double 64 bits and 15 decimal digits
		
		//char -> single characters
		
		//boolean -> true or false
		
		
		//Datatype variablename = value;
		
		int a = 5;
		int b= 6;
		float f = 100;
		
		double d = 345; // initialization
		char ch = 'a';
		boolean flag = true;
		
		
		//Arithmatic Operators -> + - * / %
		
		System.out.println(f*d);
		System.out.println(a+b);	
		
		int sum = sum(a , b);
		
		System.out.println("Sum:" + sum);
		
		//Create employees using Employee Template
		
		//new operator is used to create an object
		Employee emp = new Employee(); //instantiation , creating a new object
		emp.setEmpId( 100);
		emp.setEmpName("Employee1");
		emp.setEmailId( "sdsdf@gmail.com");
		emp.setMobile( 5455);
		emp.setSalary(678688);
		
		System.out.println("emp:" + emp);
		
		System.out.println(emp.getEmailId());
		
		Employee emp1 = new Employee(); 
		//instantiation , creating a new object
		//JVM will call the default constructor...
		
		emp1.setEmpId( 200);
		emp1.setEmpName("Employee2");
		emp1.setEmailId( "sdsdf2@gmail.com");
		emp1.setMobile( 25455);
		emp1.setSalary(2678688);
		
		System.out.println("emp1:" + emp1);
		
		System.out.println(emp1.getEmailId());
	
		//Parameterized Constructors..
		Employee emp2 = new Employee(300, "asdsad", "asdad", 3535,345);
		
		System.out.println(emp2);
		
		
	} //end of main method...
	
	public static int sum (int a, int b) {
		System.out.println("Starting sum method...");
		
		int sum = a+b;
		
		System.out.println("c=ompleted sum method...");
		
		return sum;
		
	}
	

}
