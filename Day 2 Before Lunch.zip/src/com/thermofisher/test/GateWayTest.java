package com.thermofisher.test;

import com.thermofisher.other.BillDeskGateway;
import com.thermofisher.other.PaymentGateWay;

public class GateWayTest {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PaymentGateWay gateWay = new BillDeskGateway();
		gateWay.setAmount(10000);
		gateWay.payment();
		
		
	}

}
