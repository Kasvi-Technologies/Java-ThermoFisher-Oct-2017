package com.thermofisher.test;
import com.thermofisher.other.Bike;
import com.thermofisher.other.Car;
import com.thermofisher.other.Vehicle;

public class VehicleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Car c = new Car();
		c.setVehicleId(100);
		c.setVehicleName("Maruthi");
		c.setPrice(1000000);
		
		//Method Over loading
		//Example of Compile time polymorphism
		//Polymorphism -> same name but different implementations
		//method signature should be different in arguments
		c.drive();
		c.drive(100);
			
		//ChildClass var = new ChildClass();
		Bike b= new Bike();
		b.setVehicleId(100);
		b.setVehicleName("Maruthi");
		b.setPrice(1000000);
		
		b.drive();
		
		//ParentClass var = new ChildClass();
		Vehicle v = new Car();
		v.setVehicleId(100);
		v.setVehicleName("Maruthi");
		v.setPrice(1000000);
		
		//Run time polymorphism
		//Method Overriding
		
		v.drive();
		
		//v.drive(100);
				
		System.out.println("Car:"+ c.getPrice() + " " + c.getVehicleId());
		System.out.println("bike:"+ b.getPrice() + " " + b.getVehicleId());
						
	}

}
