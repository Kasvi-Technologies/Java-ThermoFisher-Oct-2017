package com.thermofisher.test;

import java.util.StringTokenizer;

public class StringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = new String("Hi.. Good Morning Good.....");
		//heap
		// 3000
		
		String str1 = "Hi.. Good Hi Morning.....";
		//literal
		// StringPool , available in PermGenSpace
		//4000
		
		System.out.println(str == str1);
		String str2 = "Hi.. Good Hi Morning.....";
		// StringPool , available in PermGenSpace
		//4000
		System.out.println(str2 == str1);
		
		//5000
		str2 = "sample.......";		
		
		String str3 = "sample.......";
		str3 = str2+"abc";
		
		String str4 = "sample.......abc";
		
		System.out.println(str4==str3);
		System.out.println(str2 == str1);
		System.out.println(str3 == str2);
		System.out.println("Length of str:" +str.length());
		
		System.out.println(str.indexOf("Good"));
		
		str.lastIndexOf("..");		
		str.toLowerCase();		
		str.toUpperCase();		
		str.endsWith("....");		
		str.startsWith("Hi");		
		str.trim(); //used to remove extra white spaces
		str.substring(4, 15);
		str.replace("Hi", "Joy");
		str.replaceAll("Hi", "Joy");
		str.charAt(3);
		
		str.equals(str1); // string content comparision
		
		//str == str1 ; this one will check the memory location
		str.equalsIgnoreCase(str1);
		
		str = str + "modifed";
				
		str = str+ "modified again...";		
		
		System.out.println(str);
		
		for (int i = str.length() -1 ; i>=0 ;i--){
			System.out.print(str.charAt(i));
		}
		
		//Example of StringBuffer
			System.out.println("");
			
			
		StringBuffer sb = new StringBuffer(str);
		sb.append("Using StringBuffer");
		//it will not create different memory locations
		//it will append in the same memory location
		
		System.out.println(sb.toString());
		
		System.out.println(sb.reverse());
		
		System.out.println(sb.length());
		
		//StringBUffer is an Synchronized Object
		
		StringBuilder sb1 = new StringBuilder(str);
		//StringBuilder is not an Synchronized object
		
		
		//Divide your string into tokens based on delimeter
		StringTokenizer st = new StringTokenizer(str , " ");
		while (st.hasMoreTokens()){
			String token  = st.nextToken();
			//wwrite your BL
			System.out.println(token);
		}
		
		
		
		
		
		
		
		
				
	}

}
