package com.thermofisher.collectionsex;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.thermofisher.beans.Employee;

public class ArrayListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List list = new ArrayList();
		
		int p = 100;
		
		//For every data type, java has the Wrapper class
		
		//int -> Integer
		//byte - > Byte
		//short -> Short
		//long -> Long
		
		//float -> Float
		//double -> Double
		
		//char -> Char
		//boolean -> Boolean
		//when ever you are storing a primitive data type into list,
		//java will convert into an respective wrapper class and stores it.
		
		//Auto boxing
		
		
		
		list.add(p); //0
		list.add(200); //1
		
		
		list.add("HI....."); //3
		list.add(5564.89); //4
		
		Employee emp = new Employee(1, "assa", "345", 345,345);
		list.add(emp); //5
		
		list.add(2, "Modified value");  // 2nd location
		list.remove(1);
		
		System.out.println("size:" + list.size());
		
		System.out.println(list.get(2));
		
		System.out.println(list.contains(100));// true or false
		
		System.out.println("NOrmal for loop...");
		for (int i = 0; i< list.size(); i++) {
			Object obj = list.get(i);
			System.out.println(obj);
		}
		
		System.out.println("Using iterator approach..");
		
		//Anonymous classes....
		Iterator itr = list.iterator();
		
		while(itr.hasNext()){ 
			Object obj = itr.next();		
			System.out.println(obj);
		}		
		
	}

}
