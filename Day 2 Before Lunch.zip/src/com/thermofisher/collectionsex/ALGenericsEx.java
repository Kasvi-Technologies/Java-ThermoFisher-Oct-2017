package com.thermofisher.collectionsex;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ALGenericsEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Generic-> Template
		//Using generics, you can specify only particular datatype 
		// you want to store in collection
		
		//List<Integer> intList = new ArrayList<Integer>();
		
		List<Integer> intList = new LinkedList<Integer>();
		
		intList.add(100);
		intList.add(200);
		intList.add(500);
		intList.add(500);
		intList.add(300);
		
		System.out.println(intList.size());
		
		//write normal loop
		System.out.println("normal for loop....");
		for (int i = 0; i< intList.size();i++) {
			Integer in = intList.get(i);
			System.out.println(in);
			
		}
		//write iterator to repeat the collection
		System.out.println("Using iterator....");
		
		Iterator<Integer> intListItr = intList.iterator();
		System.out.println(intListItr);
		while (intListItr.hasNext()){
			Integer in = intListItr.next();
			System.out.println(in);
		}
		
		System.out.println("For loops for generics....");
		
		for (Integer in : intList){
			System.out.println(in);
		}
		
		//Excercie
		//Create an EmpList which should should accept only
		//employee objects...
		
		//add 3-4 employees
		
		//display the employes using all 3 approaches..
		
		
	}

}
