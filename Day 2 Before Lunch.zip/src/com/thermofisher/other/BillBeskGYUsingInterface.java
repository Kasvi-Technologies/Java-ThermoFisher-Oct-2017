package com.thermofisher.other;

public class BillBeskGYUsingInterface
						implements GatewayInterface {

	@Override
	public void payment() {
		// TODO Auto-generated method stub
	
		// TODO Auto-generated method stub
		System.out.println("BL based on BillDesk Gateway");
			
		System.out.println("Payment of amount using default val:" +g);
				
		//Write the BL using amount to pay the transactions.
	}
	
	
}
