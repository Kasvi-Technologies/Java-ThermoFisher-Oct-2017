package com.thermofisher.beans;

public class StaticEx {

	public int a ;
	public static int b;
	
}

