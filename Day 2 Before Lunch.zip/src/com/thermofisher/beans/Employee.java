package com.thermofisher.beans;

//Class is called as a template or blue print
//Data Hiding Design Pattern

//Wrapping of Data and Functions together into an single unit is called
//as an Encapsulation
//OOPS Concept

//Java Beans or Java POJO classes
public class Employee {

	public Employee(){
		System.out.println("Constructor...");
		//BL....
	}
	
	public Employee(int empId, String empName,  String emailId, double salary, long mobile) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.emailId = emailId;
		this.mobile = mobile;
		
		//BL
	}



	private int empId;
	
	//to hold group of characters at the same time
	private String empName;
	
	private double salary;
	private String emailId;
	private long mobile;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	
	public String toString(){
		return empId+ " " + empName+ " " + emailId + " " +mobile + salary;
	}	
}
