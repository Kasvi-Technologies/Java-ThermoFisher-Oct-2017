package com.thermofisher.other;

public class Vehicle {

	private int vehicleId;
	private String vehicleName;
	private double price;
	
	
	public int getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	//Business logic method
	
	public void drive(){
		System.out.println("Vehicle:Business logic for drive");
	}
	
}
