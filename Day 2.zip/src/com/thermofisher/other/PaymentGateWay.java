package com.thermofisher.other;

//Not possible
//new PaymentGateway();
// you can't create an instance to your abstract class.

public abstract class PaymentGateWay {

	//abstract class can have non-abstract methods....
	
	private double amount;	
	
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public abstract void payment();
}
