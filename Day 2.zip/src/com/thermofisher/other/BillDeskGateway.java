package com.thermofisher.other;

public class BillDeskGateway 
				extends PaymentGateWay{

	@Override
	public void payment() {
		// TODO Auto-generated method stub
		System.out.println("BL based on BillDesk Gateway");
		
		System.out.println("Payment of :" + this.getAmount());
		
		//Write the BL using amount to pay the transactions.
	}
	
	

}
