package com.thermofisher.other;

public interface GatewayInterface {

	//variables are by default public, static  and constants;
	
	int g = 100;
	// you no need to provide abstarct keyword in interface
	// by default all methods are abstarct
	public void payment();
}
