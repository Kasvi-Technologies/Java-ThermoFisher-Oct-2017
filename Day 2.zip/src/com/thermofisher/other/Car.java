package com.thermofisher.other;
//extends is the keywords is used for inheritance

public class Car extends Vehicle{

	//Method Overriding...
	//Overriding a method from parent class to child class
	//Method signature should be same in both parent and child classes
	
	public void drive(){
		drive(100);
		System.out.println("Car:Business logic for drive");
	}
	
	//Method Overloading
	//Method name should be same and different method signature
	//should exists with in the same class.
	
	public void drive(int speed){
		System.out.println("Car:Business logic for drive with speed");
	}
}
