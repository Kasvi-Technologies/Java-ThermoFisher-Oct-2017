package com.thermofisher.other;

public class Bike extends Vehicle{

	public void drive(){
		
		System.out.println("Bike:Business logic for drive");
	}
}
