package com.thermofisher.beans;

//Class is called as a template or blue print
//Data Hiding Design Pattern

//Wrapping of Data and Functions together into an single unit is called
//as an Encapsulation
//OOPS Concept

//Java Beans or Java POJO classes
public class Employee implements Comparable<Employee> {

	private void testPrivate(){
		System.out.println("private methods..");
	}
	
	@Override
	public int compareTo(Employee emp) {
		// TODO Auto-generated method stub
		
		//Write business logic to compare 2 objects
		//sort based on employee id's.....
		
		if(this.empId < emp.empId){
			return -1; //descending
		} else if(this.empId > emp.empId){
			return 1; //ascending
		} else {
			return 0; //equals
		}
	}
	
	public Employee(){
		System.out.println("Constructor...");
		//BL....
	}
	
	public Employee(int empId, String empName,  String emailId, double salary, long mobile) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.emailId = emailId;
		this.mobile = mobile;
		
		//BL
	}



	private int empId;
	
	//to hold group of characters at the same time
	private String empName;
	
	private double salary;
	private String emailId;
	private long mobile;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	
	public String toString(){
		return empId+ " " + empName+ " " + emailId + " " +mobile + " " + salary;
	}	
	
	//you need to provide hashCode and equals method...
	
	public int hashCode(){
		return empId + empName.hashCode() + emailId.hashCode(); //100
	}
	
	public boolean equals(Object obj){		
		if(! (obj instanceof Employee)){
			return false;
		}		
		Employee emp = (Employee) obj;		
		if(this.empId == emp.empId 
				&& this.empName.equals(emp.getEmpName())
				&& this.emailId.equals(emp.getEmailId())
				&& this.mobile == emp.getMobile()
				&& this.salary == emp.getSalary()){			
			return true;
		}		
		return false;
		 
	}

	
}
