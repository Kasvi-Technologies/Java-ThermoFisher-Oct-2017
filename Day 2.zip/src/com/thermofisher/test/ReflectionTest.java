package com.thermofisher.test;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.thermofisher.beans.Employee;

public class ReflectionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//will provide extra flexibilities to access methods dynamically
		
		try {
			//using empClass, you can access metadata of employee
			Class empClass = 
					Class.forName("com.thermofisher.beans.Employee");
			
			System.out.println(empClass.getName());
			
			Method m[] = empClass.getMethods();	
			//public methods....
			
			
			Method privateMEthod =
					empClass.getDeclaredMethod("testPrivate", null);
			privateMEthod.setAccessible(true);
			privateMEthod.invoke(new Employee(), null);
			
			
			Field f[] = empClass.getFields();
			
			Field field = empClass.getDeclaredField("empId");
			field.setAccessible(true);
			Employee emp = new Employee();
			emp.setEmpId(100);			
			System.out.println("empId value:" + field.get(emp));// return 100
			
			for (Method method :m){
				method.setAccessible(true);
				System.out.println(method.getName());
				//method.invoke(new Employee(), null);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
