package com.thermofisher.test;

import com.thermofisher.beans.Employee;

public class ConditionalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 100;
		// < > <= >= !=
		if (a < 100) {
			System.out.println("BL for a<100");
		} else if (a < 200){
			System.out.println("BL for a<200");
		} else {
			System.out.println("BL for a more than 200");
		}
		
		//Looping statements
		
		//while, for and do-while
		
		//repeat from 1 to 100
		int sum = 0;
		for (int i=1; i<=100;i++){
			System.out.println(i);
			if (i == 50){
				continue;
			}
			
			if(i > 75) {
				break;
			}
			sum = sum + i;
		}
		
		System.out.println("sum:" + sum);
		
		System.out.println("using while loops");
		int j = 1;
		while (j<=10){
			System.out.println(j);
			j++;
		}
		
		
		//Array
		// to hold multiple values and same datatype
		// size is fixed.
		
		int a1[] = new int[10];
		
		
		//a1[0], a1[1],.a..a..a..a..a..a..a., a1[9];
		
		for (int i=0; i< 5;i++) {
			a1[i] = i * i;
		}
		
		
		System.out.println(a1.length);
		
		for (int i = 0; i< a1.length; i++){
			System.out.println(a1[i]);
		}
		
		Employee [] emp  = new Employee[2];
		
		emp[0] = new Employee();
		emp[0].setEmailId("fdsfdsf");
		
		emp[1] = new Employee();
 		
		String [] str = new String[3];
		str[0] = "Hi";
		str[1] = "dsfdsf";
		str[2] = "dfdsf";
		
		
		
		
	}

}
