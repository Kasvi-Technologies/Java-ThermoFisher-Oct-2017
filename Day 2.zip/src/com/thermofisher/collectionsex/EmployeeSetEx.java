package com.thermofisher.collectionsex;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.thermofisher.beans.Employee;

public class EmployeeSetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Set<Employee> empSet = new HashSet<Employee>();
		
		Set<Employee> empSet = new TreeSet<Employee>();
		
		
		Employee emp1 = new Employee(1, "abc" , "fdgdgf", 45, 45);
		Employee emp2 = new Employee(5, "gfdgdg" , "dfgfdg", 45, 45);
		Employee emp3 = new Employee(1, "abc" , "fdgdgf", 45, 45);
		Employee emp4 = new Employee(3, "eretet" , "dfg", 45, 45);
		
		
		boolean flag = emp1.equals(emp2);
		
		empSet.add(emp1); //100
		empSet.add(emp2); //200
		empSet.add(emp3);
		empSet.add(emp4);
		
		for (Employee e : empSet){
			System.out.println(e);
		}
		
	}

}
