package com.thermofisher.collectionsex;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class HashSetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Set<String> strSet = new HashSet<String>();		
		
		Set<String> strSet = 
						new TreeSet<String>(Collections.reverseOrder());
		//sorted order.....
		
		strSet.add("Hi");
		strSet.add("Abc");
		strSet.add("AAAbc");
		strSet.add("dsfdgdsg");		
		strSet.add("fgdgdgf");
		strSet.add("eeeee");
		
		boolean flag = strSet.add("Hi");
		
		if (flag == false){
			//unable to add the element i.e duplicate element
			System.out.println("duplicate element");
		}
		
		strSet.add("iH");
		System.out.println(strSet.size());
		System.out.println("using enhanced for loops..");
		for (String str : strSet){
			System.out.println(str);
		}
		System.out.println("using iterator.");		
		Iterator<String> strSetItr = strSet.iterator();
		while(strSetItr.hasNext()){
			String s = strSetItr.next();
			System.out.println(s);
		}
		
	}

}
